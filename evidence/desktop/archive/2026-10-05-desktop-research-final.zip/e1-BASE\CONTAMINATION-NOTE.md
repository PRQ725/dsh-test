# ⚠️ e1-BASE 是 **CONTAMINATED**，不得用作 existing-session immutability baseline

- **采集时间**：2026-10-04 22:18:34
- **采集条件**：**browser-lab (0.1.5-rc.3, PID 12040) 正在运行**
- **状态**：**BASELINE CONTAMINATION / FALSE POSITIVE**
- **处置**：**保留**作为实验历史 evidence；**不再**作为严格基线使用

---

## 1. 污染事实

本 workspace 的研究会话自身在 BASE 采集之后继续写入：

```
--D-Projects-dsh-test--
session-665e3202-af85-462f-a897-7cd662332be1\session.v3.jsonl.zstd

  4,312,958 B   （E1-A 前）
  4,415,133 B   （用户观察点）
  4,638,765 B   （2026-10-05 12:51:38，本记录撰写时）
```

这是 **当前 DSH 研究会话自身持续输出**造成的增长，**与 Desktop 无关**。

⇒ 用 e1-BASE 做 `CONTENT-CHANGED` 判定会把**自污染**误判为 **Desktop pollution**。

---

## 2. 为什么必须改为 quiescent baseline

`capture-shared-state.ps1` 的 `session-inventory.csv` 对每个 session 记录 SHA-256。
只要**任一 DSH host 在运行**，该 host 承载的会话就会持续增长，从而：

- 产生必然的 `CONTENT-CHANGED`
- 使 `existing-session pollution guard` 永远 FAIL
- 使结论不可归因

**唯一可用的基线条件**：

```
Desktop            OFF
browser-lab        OFF
3080 / 3180        无 LISTEN
无任何 dsh host 在写 $DSH_HOME
```

---

## 3. 替代基线

正式的严格基线必须重新采集为：

```
evidence\desktop\runtime\e1-BASE-QUIESCENT\
```

采集命令（在**外部 PowerShell**、停机后执行）：

```powershell
$D  = 'D:\Projects\dsh-test\scripts\desktop-runtime-experiment'
$RT = 'D:\Projects\dsh-test\evidence\desktop\runtime'
& "$D\capture-shared-state.ps1" -OutDir "$RT\e1-BASE-QUIESCENT" -Label baseline-quiescent
& "$D\detect-runtime-test-session.ps1" -OutDir "$RT\e1-BASE-QUIESCENT"
```

> 注意：**本 DSH 会话自身也必须停止**，否则它仍会持续写入 `session-665e3202`。
> 这正是必须由人类在外部 PowerShell 执行的原因。

---

## 4. 对既有产物的处理

| 产物 | 处置 |
|---|---|
| `e1-BASE\`（19 文件） | **保留**，仅作历史 evidence；已标注污染 |
| `e1-BASE-A-compare\` | **保留**；其中的 `CONTENT-CHANGED` 含自污染，不得据此判定 Desktop |
| `e1-BASE-QUIESCENT\` | **待人类采集**（`e1-capture.ps1` 已改为以它为 guard 依据） |

**不删除任何既有 evidence。**
