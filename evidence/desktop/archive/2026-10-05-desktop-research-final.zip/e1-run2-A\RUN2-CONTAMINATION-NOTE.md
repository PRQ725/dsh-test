# E1 run2: Stage A OPERATIONALLY SUCCESSFUL but ATTRIBUTION-CONTAMINATED

Status: **PRESERVED — do not delete, do not overwrite, do not continue to B/C**
Written: 2026-10-05 (local, UTC+8)
Artifacts: `evidence\desktop\runtime\e1-run2-A\` (20 files), `e1-run2.session.lock.json`

---

## 1. What succeeded in run2 Stage A

[FACT] Desktop 0.2.0-rc.2 created a **v4** session in the isolated run2 workspace:

```
workspace dir : C:\Users\user02\.dsh\sessions\--D-Projects-dsh-desktop-runtime-test-2--
formats       : v4:1
session count : 1
most recent   : session-944c61ce-dbf6-4bc6-aa79-9fbb05d0a55d
  file        : session.v4.jsonl.zstd
  size        : 16640 B
  sha256      : A1D877A9E9E9148DFEED08FF8EFF104BB5397B8BECE700F58A7CC9E6543D5921
  projcache   : ...\session-944c61ce-dbf6-4bc6-aa79-9fbb05d0a55d.json
```

[FACT] `capture pipeline valid = True` — all three capture children ran, every sentinel was
present and non-empty, and the sanity minimums passed (`sessions=57 shared-state=30`).
[FACT] `C. DESTRUCTIVE CHANGE : 0`.
[FACT] All profile / home / global invariants passed:
`home cordis.patch.yml = ABSENT`, `home package.json = ABSENT`,
`browser-lab/package.json`, `browser-lab/cordis.patch.yml`, `web/package.json`,
`web/cordis.patch.yml`, `AGENTS.md (global)` all unchanged.
[FACT] The settings churn matched the known cross-version model exactly and was classified
as EXPECTED:

```
A. EXPECTED CROSS-VERSION SETTINGS CHURN : 2
    GONE      settings.yaml   (Desktop 0.2 renamed it to .imported)
    CHANGED   settings.yaml.imported   (cross-version settings churn)
```

[FACT] The exact session lock was written and is internally consistent:
`RunName=run2`, `WorkspacePath=D:\Projects\dsh-desktop-runtime-test-2`,
`SessionId=session-944c61ce-dbf6-4bc6-aa79-9fbb05d0a55d`, `Format=v4`, `SizeAtLock=16640`.

**Conclusion:** the Stage A Desktop behaviour that this experiment exists to test
(create a v4 session, import legacy settings non-destructively, leave profiles untouched)
was observed and is good evidence.

## 2. Why run2 is nevertheless NOT usable for strict attribution

Two independent defects, both of which must be fixed before a run may be used to attribute
pollution to Desktop alone.

### 2.1 Defect 1 — baseline path binding was broken (tooling bug)

```
[WARN] previous stage directory not found: ...\e1-run2-BASE
[STOP] previous stage capture dir missing: ...\e1-run2-BASE  (stage sequence broken)
```

`e1-capture.ps1` **derived** the Stage A predecessor as `e1-<RunName>-BASE`
(`e1-run2-BASE`), which never existed. The valid, revalidated baseline was
`e1-BASE-QUIESCENT-R2`. Worse, the same script's change classifier used the correct
baseline, so the run had **two different baselines** in one report: an imaginary one for the
diff and a real one for the classifier.

Consequence: **the baseline → A diff never ran**, so `diff valid = False` and no
zero-Delta baseline→A comparison exists for run2. Fixed in the tooling (see §4).

### 2.2 Defect 2 — the baseline → A interval was not Desktop-only (operational)

The classifier recorded:

```
B. UNEXPECTED CONTENT CHANGE : 4
    CHANGED   .dshw-turn.json
    CHANGED   .dshw-usage.json
    CHANGED   storages\workspace.json
    SESSION CONTENT CHANGED  --D-Projects-dsh-test--\session-665e3202-af85-462f-a897-7cd662332be1\session.v3.jsonl.zstd
              : lastType=turn/end events=4793->5059
```

`--D-Projects-dsh-test--` is **this research workspace**. The growth 4793 → 5059 events is
this research session continuing — it happened because the research host (browser-lab /
`dsh-test`) was restarted after the quiescent baseline was captured and only stopped again
before Desktop was launched.

Therefore, between `e1-BASE-QUIESCENT-R2` and `e1-run2-A`, **more than one thing changed**.
Desktop was not the only active variable, and the dsh-test session growth cannot be
attributed to Desktop.

[FACT] The classifier did its job correctly here: it refused to treat the growth as benign
and classified it as class B (unexpected content change requiring human review).
[FACT] The `.dshw-*` and `storages\workspace.json` changes are likewise consistent with the
research host having run in the interval.
[INFERENCE] Had the run proceeded, Stage B/C would have compared against a baseline that was
older than the research activity, making every subsequent diff ambiguous.

## 3. Disposition of run2

| Item | Disposition |
|------|-------------|
| `e1-run2-A\` (20 files) | **KEEP as-is.** Never delete, never overwrite, never re-capture. |
| `e1-run2.session.lock.json` | **KEEP as-is.** |
| `e1-BASE-QUIESCENT-R2` / `-VERIFY` | **KEEP as-is.** Valid content baseline; bound to run3. |
| Stage B / Stage C for run2 | **MUST NOT PROCEED.** Reading a session in a contaminated interval adds no attribution value and would consume the single run2 session. |
| Re-use of `--D-Projects-dsh-desktop-runtime-test-2--` | **NO.** run3 uses a fresh workspace so the run2 session stays readable as evidence. |

Classification: **OPERATIONALLY SUCCESSFUL, ATTRIBUTION-CONTAMINATED.**

A future reader must not cite the run2 A→B→C chain as evidence of Desktop-only pollution;
the Stage A observations in §1 may be cited as Desktop behaviour.

## 4. What was changed so run3 cannot repeat either defect

1. **Explicit baseline binding.** `capture-run-config.ps1` + `e1-<RunName>.metadata.json`
   declare the workspace, the sealed baseline and every stage directory. `e1-capture.ps1`
   reads that file and has exactly one baseline variable; Stage A's predecessor is the
   declared baseline. Deriving `e1-<RunName>-BASE` is impossible, and `-Stage BASE` no
   longer exists.
2. **Baseline sealing.** A baseline is usable only after the capture wrapper reports PASS
   **and** writes `E1-BASELINE-BINDING.json` into the baseline directory **and** flips
   `BaselineVerified` in the metadata. Missing, unsealed, foreign or post-seal-drifted
   baselines all STOP before any interpretation.
3. **Strict baseline → A continuity.** The run3 procedure (§ run3 metadata) captures the
   baseline and then goes straight to Desktop **without** restarting the research host, so
   Desktop is the only active variable.
4. **Fail-closed tests.** `e1-binding.selftest.ps1` covers correct binding plus the four
   STOP conditions (missing baseline, foreign baseline, workspace mismatch, lock mismatch)
   and post-seal drift: 35 passed / 0 failed.

## 5. Explicit statement for the record

[FACT] run2 Stage A Desktop session creation succeeded, the v4 exact session lock
succeeded, destructive change was 0, and the settings churn matched the known model.
[FACT] The previous-stage baseline path binding was broken.
[FACT] The baseline → A interval contained `dsh-test` research activity
(session-665e3202 grew 4793 → 5059 events).
[INFERENCE] run2 is therefore NOT valid for strict Desktop-only pollution attribution.
[DECISION] run2 B/C must not proceed; run3 replaces run2 for the A→B→C chain.
